Lightline colorschemes
======================

These are the color schemes for the Lightline plugin which sets the status
line. The light and dark one are pretty much the same except the `baseX` and
`base0X` colors are each swapped.
